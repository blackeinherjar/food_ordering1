package ChromeBrowser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import java.util.Random;
import java.util.Scanner;


public class LaunchApplication {
	
	public static void main(String[] args) throws InterruptedException
	{
		Scanner user_input = new Scanner(System.in);  
		System.setProperty("webdriver.chrome.driver", "C:\\ChromeDriver\\chromedriver.exe"); //must include 
		String TestWeb_Address = "http://localhost/food_ordering";  //my website
		
		System.out.println("1:Test Login");
		System.out.println("2:Test Register");
		System.out.println("3:Exit");
	
		int choice = user_input.nextInt();
		switch(choice)
		{
		case 1:
			admin_login(TestWeb_Address);
			break;
		case 2:
			register(TestWeb_Address);
			break;
		default:
			System.exit(0);
		}
	}
	
	//generate random email
	private static String getSaltString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 10) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;
        
      //getSaltString()+"@gmail.com"
    }
	
	
	//generate random firstname
	private static String getFirstName() {
		String FirstName;
		Random rn = new Random();
		int result = rn.nextInt(10) + 1;
		
		switch(result){
		case 1:
			FirstName = "Jack";
			break;
		case 2:
			FirstName = "Mike";
			break;
		case 3:
			FirstName = "Alice";
			break;
		case 4:
			FirstName = "Sharon";
			break;
		case 5:
			FirstName = "Lily";
			break;
		case 6:
			FirstName = "Ron";
			break;
		case 7:
			FirstName = "Harry";
			break;
		case 8:
			FirstName = "Herminy";
			break;
		case 9:
			FirstName = "Shiny";
			break;
		case 10:
			FirstName = "Taurus";
			break;
		default:
			FirstName = "Yuri";
	
		}
		return FirstName;
	}
	
	//generate random lastname
	private static String getLastName() {
		String LastName;
		Random rn = new Random();
		int result = rn.nextInt(10) + 1;
		
		switch(result){
		case 1:
			LastName = "Smith";
			break;
		case 2:
			LastName = "Johnson";
			break;
		case 3:
			LastName = "Williams";
			break;
		case 4:
			LastName = "Brown";
			break;
		case 5:
			LastName = "Thomas";
			break;
		case 6:
			LastName = "Robinson";
			break;
		case 7:
			LastName = "Scott";
			break;
		case 8:
			LastName = "Phillips";
			break;
		case 9:
			LastName = "Flores";
			break;
		case 10:
			LastName = "Rivera";
			break;
		default:
			LastName = "Rogers";
	
		}
		return LastName;
	}
	
	//generate random age
	private static int getAge() {
		Random rand = new Random();
		int  n = rand.nextInt(50) + 1;
		return n;
	}
	
	//generate random contact no
	private static String getContact() {
		String Contact_no;
		Random rn = new Random();
		int result = rn.nextInt(10) + 1;
		
		switch(result){
		case 1:
			Contact_no = "0123456672";
			break;
		case 2:
			Contact_no = "0123499972";
			break;
		case 3:
			Contact_no = "0182223333";
			break;
		case 4:
			Contact_no = "0116227381";
			break;
		case 5:
			Contact_no = "0152263391";
			break;
		case 6:
			Contact_no = "0132223901";
			break;
		case 7:
			Contact_no = "0112263811";
			break;
		case 8:
			Contact_no = "0123465921";
			break;
		case 9:
			Contact_no = "0128371910";
			break;
		case 10:
			Contact_no = "0189223711";
			break;
		default:
			Contact_no = "0198227361";
		}
		return Contact_no;
	}
	
	//generate random address
		private static String getAddress() {
			String Address;
			Random rn = new Random();
			int result = rn.nextInt(10) + 1;
			
			switch(result){
			case 1:
				Address = "Penang";
				break;
			case 2:
				Address = "Kedah";
				break;
			case 3:
				Address = "Sabah";
				break;
			case 4:
				Address = "Sarawak";
				break;
			case 5:
				Address = "Selangor";
				break;
			case 6:
				Address = "Perlis";
				break;
			case 7:
				Address = "Johor";
				break;
			case 8:
				Address = "Negeri Sembilan";
				break;
			case 9:
				Address = "Terengganu";
				break;
			case 10:
				Address = "Melaka";
				break;
			default:
				Address = "Penang";
			}
			return Address;
		}
	
	
	//test admin login
	private static void admin_login(String website) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get(website);
		driver.findElement(By.id("email")).sendKeys("admin@gmail.com"); //find element (can by: id,name,classname ... ) // sentKeys -> what u want to sent through
		driver.findElement(By.id("pass")).sendKeys("123456");
		driver.findElement(By.id("submit")).click();
		Thread.sleep(5000); //delay 5 seconds
		driver.quit(); //exit web
	}
	
	private static void register(String website) throws InterruptedException {
		
		int age = getAge();
		String first_name = getFirstName();
		String last_name = getLastName();
		String contact_no = getContact();
		String address = getAddress();
		
		WebDriver driver = new ChromeDriver(); //must have 
		driver.get(website);
		driver.findElement(By.xpath("//a[contains(text(),'Register an Account')]")).click();  //find a tag with the text (Register an Account) in between,then click on it  
		
		Thread.sleep(1000); //wierd problem.item inside modal wont pop up without delay
		
		driver.findElement(By.className("modal-body")).findElement(By.name("email")).sendKeys(getSaltString()+"@gmail.com"); //find element 2 times because inside modal
		driver.findElement(By.className("modal-body")).findElement(By.name("pass")).sendKeys("123456");
		driver.findElement(By.className("modal-body")).findElement(By.name("first_name")).sendKeys(first_name);
		driver.findElement(By.className("modal-body")).findElement(By.name("last_name")).sendKeys(last_name);
		driver.findElement(By.className("modal-body")).findElement(By.name("age")).sendKeys(String.valueOf(age)); //convert string to number
		driver.findElement(By.className("modal-body")).findElement(By.name("address")).sendKeys(address);
		driver.findElement(By.className("modal-body")).findElement(By.name("contact_no")).sendKeys(contact_no);
		
		driver.findElement(By.className("modal-footer")).findElement(By.id("submit")).click();
		
		Thread.sleep(8000); //delay 80 seconds
		
		driver.quit(); //exit website
		
	}
	
}
